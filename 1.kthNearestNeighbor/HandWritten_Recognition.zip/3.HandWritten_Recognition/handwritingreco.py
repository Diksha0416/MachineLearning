import numpy as np
import operator
from os import listdir #to see the name of files in a directory

# K-Nearest Neighbors classifier function
def classify0(inX, dataSet, labels, k):
    dataSetSize = dataSet.shape[0]
    #calculate distance
    diffMat = np.tile(inX, (dataSetSize, 1)) - dataSet 
    sqDiffMat = diffMat ** 2 
    sqDistances = sqDiffMat.sum(axis=1)  
    distances = sqDistances ** 0.5  
    # Sort distances and get the sorted indices
    sortedDisIndices = distances.argsort()  
    # Dictionary to count the occurrences of each label
    classCount = {}  
    for i in range(k):
        # To get the label with the highest count
        voteIlabel = labels[sortedDisIndices[i]]
        classCount[voteIlabel] = classCount.get(voteIlabel, 0) + 1 
    sortedClassCount = sorted(classCount.items(), key=operator.itemgetter(1), reverse=True) 
    return sortedClassCount[0][0]  

# To store the content of file in a single row
def img2vector(filename):
    returnVect = np.zeros((1,1024))
    fr = open(filename)
    for i in range(32):
        lineStr = fr.readline()
        for j in range(32):
            returnVect[0,32*i+j] = int(lineStr[j])
    return returnVect
#testVector = img2vector('testDigits/0_0.txt')
#print(testVector[0,65:97])

# HandWritten digits testing code
def handwritingClassTest():
    hwLabels = []
    #get content of directory
    trainingFileList = listdir('trainingDigits')
    m = len(trainingFileList)
    # To hold each image as a single row
    trainingMat = np.zeros((m,1024))
    for i in range(m):
        # 
        fileNameStr = trainingFileList[i]
        fileStr = fileNameStr.split('.')[0]
        # file name is like '1_0' where 1 is classnumber and 0 is instance of digit 1. Then we are putting the Class in hwLabels
        classNumStr = int(fileStr.split('_')[0])
        hwLabels.append(classNumStr)

        trainingMat[i,:] = img2vector('trainingDigits/%s' % fileNameStr)
    testFileList = listdir('testDigits')
    errorCount = 0.0
    mTest = len(testFileList)
    for i in range(mTest):
        fileNameStr = testFileList[i]
        fileStr = fileNameStr.split('.')[0]
        classNumStr = int(fileStr.split('_')[0])
        vectorUnderTest = img2vector('testDigits/%s' % fileNameStr)
        classifierResult = classify0(vectorUnderTest,trainingMat,hwLabels,3)
        print("The classifier came back with: %d, the real answer is: %d" % (classifierResult,classNumStr))

        if (classifierResult != classNumStr):
            errorCount += 1.0
    print("/n The total number of errors is: %d" % errorCount)
    print("/n The total Error rate is: %f" % (errorCount/float(mTest)))

handwritingClassTest()